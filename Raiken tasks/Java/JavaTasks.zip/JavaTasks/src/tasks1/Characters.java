package tasks1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Characters {

	public char returnFirstCharacter(String word) {
		
		char result = word.charAt(0);
		
		return result;
	}
	
	public int returnTheLengthOfTheWord(String word) {
	
		int length = word.length();
		
		return length;
		
	}
	
	public List<String>addWordToAList(String word) {
		
		List<String> list = new ArrayList<>();
		
		list.add(word);
		
		return list;
	}
}
