package tasks1;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class CharactersTest {

	Characters character = new Characters();
	@Test
	@DisplayName("Return the first character of a word")
	void test1() {
		
		assertEquals('H', character.returnFirstCharacter("Hello"));
	}
	
	@Test
	@DisplayName("Return the length of the word")
	void test2() {
		
		assertEquals(5, character.returnTheLengthOfTheWord("Hello"));
	}
	
	@Test
	@DisplayName("Return a list containing the given word")
	void test3() {
		
		String word = "Hello";
		
		assertEquals(List.of("Hello"), character.addWordToAList(word));
		
	}
	
}
